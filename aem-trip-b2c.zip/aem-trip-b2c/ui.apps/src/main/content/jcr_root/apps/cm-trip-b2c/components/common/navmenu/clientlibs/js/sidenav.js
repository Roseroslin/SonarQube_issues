
$(function() {
    // set path for the image


    //Goal list on desktop
    //Disable Goal list on Mobile view
     if(jQuery(window).width() > 420){
      //Goal list on desktop
         $("nav#menu2").mmenu({
         "extensions": [

             "position-front"
             ],
             "counters": true
            },{



             // configuration
             offCanvas: {
                pageSelector: ".quick-goal-list"
             }

            });
     }
        //main navigation here
				$('nav#menu').mmenu({
					extensions	:  {
                    "all": ["theme-dark"],
                    "(max-width: 420px)": ["fullscreen"]
                    },

					setSelected	: true,
					counters	: true,
					searchfield : {
						placeholder		: 'Search menu items'
					},

					sidebar		: {
						collapsed		: {
							use 			: 420,
							size			: 60,
							hideNavbar		: true,
							blockMenu		: true
						}
//						expanded		: {
//							use 			: '(min-width: 3000px)',
//							size			: 35
//						}
					},
                     navbar: {
                            title: ""
                        },
					navbars		: [
//						{
//							content		: [ 'searchfield' ]
//						},
//                        {
//							type		: 'tabs',
//							content		: [
//								'<a href="#panel-menu"><i class="fa fa-bars"></i> <span>Menu</span></a>'
//							]
//						},

//                        {
//							content		: [ 'prev', 'breadcrumbs', 'close' ]
//						},
//
//                        {
//                            use 		: '(max-width: 420px)',
//							position	: 'bottom',
//							content		: [ '<div class="footer-mobile"></div>' ]
//						}
					]
				}, {
					searchfield : {
						clear 		: true
					},
					navbars		: {
						breadcrumbs	: {
							removeFirst	: true
						}
					}
				});
                // Appending Footer Content to Mobile Device Navigation
                $("#listLinks-bottom").append($('footer').clone());

			}); // end of jquery mmenu declaration

