use(["/libs/wcm/foundation/components/utils/AuthoringUtils.js"], function (AuthoringUtils) {

    var appType = currentPage.getPath();

    if(appType.contains("consumer-portal"))
    {
		appType = "manulife";
    } else if(appType.contains("manulife-private-wealth")) {
		appType = "mpw";
    } else if(appType.contains("manulife-bank")) {
		appType = "bank";
    } else if(appType.contains("manulife-securities")) {
		appType = "securities";
    } else if(appType.contains("manulife-carp")) {
		appType = "carp";
    } else {
		appType = "global";
    }

    return {
        appType: appType
    };
});
